'use strict';

const database = require('../database/films');

function ApiRoutesajout(ajout, configuration, callback) {
    database(configuration, films  => {       
        app.get('/api/films', (req, res) => {
            fims.find(results => {
                res.json({ data: });
            });
        });

        app.post('/api/films', (req, res) => {
            films.add(req.body, id => {
                res.json({ success: Boolean(id) });
            });
        });        
        if (callback) callback();
    });
}

module.exports = {
    addRoutes: ApiRoutesajout
};
