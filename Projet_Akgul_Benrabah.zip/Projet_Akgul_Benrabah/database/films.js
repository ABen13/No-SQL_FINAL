'use strict';

const chalk = require('chalk');
const crypto = require('crypto');

const MongoClient = require('mongodb').MongoClient;
const COLLECTION_NAME = 'films';


function film(tr) {
    return callback => {
        tr.collection(COLLECTION_NAME).find({}).toArray((err, results) => {
            if (err) printFailure(err);
            callback(err ? [] : results);
		tr.collection(COLLECTION_NAME).find({}).count((err, count) => {
            if (err) printFailure(err);
            callback(err ? 1: count);
        });
    }
}


function filmajout(tr) {
    return (entry, callback) => {
        if (!entry) entry = {};
        var film = {
            titre: entry.titre|| '',
            realisateur: entry.titre || ''
        };
        var salt = [String(new Date()), film.titre, film.realisateur].join('|');
        film.id = crypto.createHash('md5').update(salt).digest('hex');
        tr.collection(COLLECTION_NAME).insertOne(song, (err, response) => {
            if (err) {
                printFailure(err);
                return callback(null);
            }
        });
    };
}


