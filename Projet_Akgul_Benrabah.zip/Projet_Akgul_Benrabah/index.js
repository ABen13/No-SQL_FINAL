'use strict';

const PORT = 3080;
const MONGO_URI = 'mongodb://localhost';
const TR_NAME = 'films';
const bodyParser = require('body-parser');
const express = require('express');
const chalk = require('chalk');
var appli = express();
appli.use(bodyParser.urlencoded({ extended: true }));
appli.use(bodyParser.json());
var apiRoutes = require('./routes/api');
var htmRoutes = require('./routes/pug');
var config = {
    trUri: MONGO_URI,
    trName: TR_NAME,
    apiRoot: `http://localhost:${PORT}'
}
appli.use(express.static('assets'));
apiRoutes.addRoutes(appli, configuration);
htmRoutes.addRoutes(appli, configuration);
appli.listen(PORT, () => {
    console.log(chalk.green.bold('List'), `to port ${PORT}`);
});
